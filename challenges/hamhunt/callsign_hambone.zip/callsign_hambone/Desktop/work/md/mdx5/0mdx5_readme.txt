Replace the number of the file that is not in the 'known_good_hashes.txt' file with the xxxxx in pps{3x5_md5_xxxxx}
This is going to take multiple steps!'.
