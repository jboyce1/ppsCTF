Check out the browser history and get the flag by replacing the xxx's with a spike in url's (see new-project-feedback.txt for details and just after the url after any www.) pps{3x3_midbrow-xxxx}
