Check out the browser history and get the flag by replacing the xxx's with the putting in the most visited site (just after the url after any www.) pps{2x1_lowbrow-xxxx}
