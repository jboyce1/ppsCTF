import random
import string

# Configuration
box_value = "4"
challenge_value = "2"
flag_template = "pps{{{}x{}_dif&cmp-{}}}"
total_changes = 12  # Total number of changes to make

# Generate a random flag code
def generate_flag_code(length):
    return ''.join(random.choices(string.ascii_letters + string.digits, k=length))

# File paths
original_file_path = 'state-of-union-reagan.txt' #adjust this to match the input file
modified_file_path = 'state-of-union-reagan_modified.txt'

# Read the original file
with open(original_file_path, 'r', encoding='utf-8') as file:
    original_text = file.readlines()

# Filter out lines that are too short for modification
valid_lines = [index for index, line in enumerate(original_text) if len(line) > 1]

# Decide on locations to insert flags, ensuring only valid lines are selected
if len(valid_lines) < total_changes:
    raise ValueError("Not enough valid lines to insert flags.")

line_indices = random.sample(valid_lines, total_changes)
flag_code = generate_flag_code(total_changes)

# Modify the text and insert flags
modified_text = original_text[:]
for idx, line_idx in enumerate(sorted(line_indices)):
    line = original_text[line_idx]
    char_idx = random.randint(0, len(line) - 2)  # -2 to avoid the newline character
    # Replace one character in the line
    new_line = line[:char_idx] + flag_code[idx] + line[char_idx + 1:]
    modified_text[line_idx] = new_line

# Save the modified file
with open(modified_file_path, 'w', encoding='utf-8') as file:
    file.writelines(modified_text)

# Prepare the full flag
full_flag = flag_template.format(box_value, challenge_value, flag_code)
print(f"Modified file saved as {modified_file_path}.")
print(f"Flag: {full_flag}")
