Check out the browser history and get the flag by replacing the xxx's with a spike in url's  and just after the url after any www.) pps{4x4_highbrow-xxxx}
see .db for details
hint: browser history is in the a typical location for browser history on ubuntu. cd and ls will make it plain.

