#!/usr/bin/env python3
import time
import psutil
import os

THRESHOLD_PERCENT = 85
REQUIRED_CONSECUTIVE_CHECKS = 2
CHECK_INTERVAL = 5
FLAG_CONTENT = "pps{4x4_memory_bully-B3kah_n3utra1ized}"
OUT_PATH = "/home/bekah1/Desktop/bullies_neutralized.txt"

def main():
    consecutive_exceeds = 0
    while True:
        mem = psutil.virtual_memory()

        if mem.percent >= THRESHOLD_PERCENT:
            consecutive_exceeds += 1
        else:
            consecutive_exceeds = 0

        if consecutive_exceeds >= REQUIRED_CONSECUTIVE_CHECKS:
            with open(OUT_PATH, "w", encoding="utf-8") as f:
                f.write("Memory usage threshold reached! The bullies have been neutralized.\n")
                f.write(f"Final Flag: {FLAG_CONTENT}\n")
            os.chmod(OUT_PATH, 0o644)
            break

        time.sleep(CHECK_INTERVAL)

if __name__ == "__main__":
    main()