#!/usr/bin/env python3
import os
import time
import socket

TCP_PORT = 6789
CHECK_INTERVAL = 5
THRESHOLD_FAILURES = 3

FLAG_CONTENT = "pps{3x2_tcp_b3k@h-blocked}"
FLAG_PATH = "/home/bekah1/Desktop/tcp_flag.txt"

CONF_PATH = "/home/brenda2/.victim2.conf"  # created by deploy

def read_victim_ip():
    if not os.path.exists(CONF_PATH):
        return None
    with open(CONF_PATH, "r", encoding="utf-8", errors="ignore") as f:
        ip = f.read().strip()
        return ip if ip else None

def tcp_reachable(ip: str, port: int, timeout=1.0) -> bool:
    try:
        with socket.create_connection((ip, port), timeout=timeout):
            return True
    except Exception:
        return False

def write_flag():
    with open(FLAG_PATH, "w", encoding="utf-8") as f:
        f.write("TCP attack successful!\n")
        f.write(f"Here is your flag: {FLAG_CONTENT}\n")
    os.chmod(FLAG_PATH, 0o644)

def main():
    failure_count = 0

    while True:
        victim_ip = read_victim_ip()
        if not victim_ip:
            time.sleep(CHECK_INTERVAL)
            continue

        if tcp_reachable(victim_ip, TCP_PORT):
            failure_count = 0
        else:
            failure_count += 1

        if failure_count >= THRESHOLD_FAILURES:
            write_flag()
            break

        time.sleep(CHECK_INTERVAL)

if __name__ == "__main__":
    main()