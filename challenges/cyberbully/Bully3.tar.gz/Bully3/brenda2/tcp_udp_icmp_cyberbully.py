#!/usr/bin/env python3
import os
import time
import random
from scapy.all import send, IP, ICMP, UDP, TCP, Raw  # requires python3-scapy installed

# === CONFIG (written by deploy script) ===
CONF_PATH = "/home/bekah1/.victim2.conf"   # deploy writes victim2 IP here (one line: 10.x.x.x)

# === NETWORK SETTINGS ===
UDP_PORT = 8765
TCP_PORT = 9876
INTERVAL = 1  # seconds

# Nasty-grams from Brenda to Vinny and Virgil
MESSAGES = [
    "Vinny, your packets time out before your ideas do.",
    "Virgil, your subnet mask can't hide how clueless you are.",
    "Vinny, even ARP doesn't want to resolve your address.",
    "Virgil, your routing table has fewer entries than your brain.",
    "Vinny, your TCP handshakes are weaker than your arguments.",
    "Virgil, you broadcast nonsense like it's a feature.",
    "Vinny, your latency matches your thinking speed.",
    "Virgil, even DNS refuses to resolve you.",
    "Vinny, your logs are as empty as your skillset.",
    "Virgil, I’ve seen null routes with more direction."
]

def read_victim_ip() -> str:
    if not os.path.exists(CONF_PATH):
        raise FileNotFoundError(f"Config not found: {CONF_PATH}")

    with open(CONF_PATH, "r", encoding="utf-8", errors="ignore") as f:
        ip = f.read().strip()

    if not ip:
        raise ValueError(f"Victim IP is blank in config: {CONF_PATH}")

    return ip

def send_bullying_messages(victim_ip: str):
    print(f"[+] Attacking {victim_ip} with cyber insults over ICMP, UDP, and TCP... (Ctrl+C to stop)")
    while True:
        message = random.choice(MESSAGES)

        # ICMP
        send(IP(dst=victim_ip)/ICMP()/Raw(load=message), verbose=0)

        # UDP
        send(IP(dst=victim_ip)/UDP(dport=UDP_PORT)/Raw(load=message), verbose=0)

        # TCP
        send(IP(dst=victim_ip)/TCP(dport=TCP_PORT)/Raw(load=message), verbose=0)

        time.sleep(INTERVAL)

def main():
    try:
        victim_ip = read_victim_ip()
    except Exception as e:
        print(f"[!] {e}")
        print("[!] Deployment should create the config file with the victim2 IP.")
        print(f"[!] Expected format: echo '10.1.1.50' > {CONF_PATH}")
        return

    send_bullying_messages(victim_ip)

if __name__ == "__main__":
    main()