#!/usr/bin/env python3
import argparse
import os
import random
import socket
import subprocess
import time

DEFAULT_CONF = "/home/becky1/.cyberbully.conf"

# Default behavior:
# 1 = cycle through MESSAGES in order
# 2 = random message each send
DEFAULT_BEHAVIOR = 1

MESSAGES = [
    "Your config is so messed, I'd trust /dev/null before trusting you.",
    "You're slower than an ARP request on a dropped cable.",
    "Your password complexity is so low, I'd let my cat guess it.",
    "Your system is so full of holes, netstat found 127.0.0.1 vulnerabilities.",
    "Your code is so buggy, even a honeypot won't talk to it.",
    "Your encryption is weaker than a WEP key from 1999.",
    "Your firewall is as open as a public library Wi-Fi hotspot.",
    "Your system logs are more confused than a DNS lookup in a black hole.",
    "You cause more trouble on the network than broadcast storms do.",
    "I've seen viruses with better version control than your scripts."
]

def parse_conf(path: str) -> dict:
    """key=value parser; ignores blanks/comments."""
    conf = {}
    if not os.path.exists(path):
        return conf
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            conf[k.strip()] = v.strip()
    return conf

def safe_int(val, default):
    try:
        return int(val)
    except Exception:
        return default

def safe_float(val, default):
    try:
        return float(val)
    except Exception:
        return default

def send_tcp(dst_ip: str, dst_port: int, payload: str, timeout=1.0):
    try:
        with socket.create_connection((dst_ip, dst_port), timeout=timeout) as s:
            s.sendall(payload.encode("utf-8", errors="ignore"))
    except Exception:
        pass

def send_udp(dst_ip: str, dst_port: int, payload: str):
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.sendto(payload.encode("utf-8", errors="ignore"), (dst_ip, dst_port))
    except Exception:
        pass

def send_icmp(dst_ip: str):
    """Uses system ping (no raw sockets needed)."""
    try:
        subprocess.run(
            ["ping", "-c", "1", "-W", "1", dst_ip],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            check=False,
        )
    except Exception:
        pass

def pick_message(behavior: int, messages: list[str], idx: int, override: str | None):
    """
    If override (config 'message=') is provided and non-empty, always use it.
    Otherwise pick from list using behavior.
    Returns (message, next_idx).
    """
    if override is not None and override.strip() != "":
        return override, idx

    if not messages:
        return "…", idx

    if behavior == 2:
        return random.choice(messages), idx
    # default: cycle
    msg = messages[idx % len(messages)]
    return msg, idx + 1

def main():
    ap = argparse.ArgumentParser(description="TCP/UDP/ICMP cyberbully traffic generator (varied messages + live reload).")
    ap.add_argument("--config", default=DEFAULT_CONF, help="Path to config file")
    ap.add_argument("--once", action="store_true", help="Send once and exit")
    args = ap.parse_args()

    conf_path = args.config
    last_mtime = None
    msg_idx = 0

    # Defaults
    victim_ip = None
    tcp_port = 31337
    udp_port = 31337
    interval = 2.0
    behavior = DEFAULT_BEHAVIOR
    message_override = None  # if config sets message=..., use that only

    print(f"[+] Cyberbully generator starting. Config: {conf_path}")
    print("[+] Edit config live; it reloads automatically.")
    print("[+] Behaviors: 1=cycle messages, 2=random messages")

    while True:
        # Reload config if file changed
        try:
            mtime = os.path.getmtime(conf_path) if os.path.exists(conf_path) else None
        except Exception:
            mtime = None

        if mtime != last_mtime:
            last_mtime = mtime
            conf = parse_conf(conf_path)

            victim_ip = conf.get("victim_ip", victim_ip)
            tcp_port = safe_int(conf.get("tcp_port"), tcp_port)
            udp_port = safe_int(conf.get("udp_port"), udp_port)
            interval = safe_float(conf.get("interval"), interval)
            behavior = safe_int(conf.get("behavior"), behavior)

            # Optional override: if you set message=... it will *replace* the rotating list
            if "message" in conf:
                message_override = conf.get("message")
            else:
                message_override = None

            print(f"[~] Reloaded: victim_ip={victim_ip}, tcp_port={tcp_port}, udp_port={udp_port}, interval={interval}, behavior={behavior}, override={'yes' if message_override else 'no'}")

        if not victim_ip:
            victim_ip = input("Victim IP: ").strip()

        msg, msg_idx = pick_message(behavior, MESSAGES, msg_idx, message_override)

        # Send three “channels”
        send_tcp(victim_ip, tcp_port, msg)
        send_udp(victim_ip, udp_port, msg)
        send_icmp(victim_ip)

        # Print locally so you can see rotation when running interactively
        print(f"[>] Sent to {victim_ip} (tcp:{tcp_port} udp:{udp_port}) msg='{msg[:80] + ('…' if len(msg) > 80 else '')}'")

        if args.once:
            return

        time.sleep(max(0.2, interval))

if __name__ == "__main__":
    main()