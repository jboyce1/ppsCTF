#!/usr/bin/env python3
import os
import subprocess
import time
import signal
import sys
import re
import random

# =========================
# Install tools (now includes netcat-openbsd)
# =========================
def install_tools():
    print("[+] Installing required tools (Scapy, tcpdump, iftop, nmap, netcat)...")
    env = os.environ.copy()
    env["DEBIAN_FRONTEND"] = "noninteractive"
    subprocess.run(["sudo", "apt-get", "update"], env=env, check=True)
    subprocess.run(
        ["sudo", "apt-get", "install", "-y",
         "tcpdump", "iftop", "nmap", "netcat-openbsd", "python3-scapy"],
        env=env,
        check=True
    )
    print("[+] Required tools installed!")

def check_and_import_scapy():
    """
    Attempts to import Scapy. If it fails, installs the necessary packages
    and then restarts the script.
    """
    try:
        from scapy.all import send, IP, TCP, Raw
        return send, IP, TCP, Raw
    except ImportError:
        print("[!] Scapy not installed. Installing now...")
        install_tools()
        print("[+] Tools installed. Restarting the script...")
        os.execv(sys.executable, [sys.executable] + sys.argv)

# Now import scapy functions after ensuring they are installed.
send, IP, TCP, Raw = check_and_import_scapy()

# =========================
# CONFIGURATION
# =========================
BOX_VALUE = "1"
CHALLENGE_VALUE = "2"
INSERT_FLAG_CODE = "tcpv1cP@ass-BR0"
TCP_PORT = 6666

MESSAGE = (f"pps{{{BOX_VALUE}x{CHALLENGE_VALUE}_geist_{INSERT_FLAG_CODE}}} "
           "I would really appreciate some help from anyone who can see this, my brother is being bullied..."
           "a group of sisters, who all have the same stupid first letter of their name"
           " has been harrassing our computer. My brother stopped using the computer so "
           " I am giving his username and password in case you can help u:vinny2 p:vin4theWIN!"
           " Thanks for any help -virgil")

# Rescan every 5 minutes so late logins get the message quickly
NETWORK_RESCAN_INTERVAL = 300  # 5 minutes
BROADCAST_INTERVAL = 10
DETECTED_HOSTS_FILE = "hosts.txt"

# Scan tuning (AWS/cyber.org friendly)
NMAP_HOST_TIMEOUT = "800ms"
NMAP_MAX_RETRIES = "0"
NC_TIMEOUT_SEC = 1

# =========================
# Graceful shutdown
# =========================
STOP = False
def handle_exit(sig, frame):
    global STOP
    print("\n[!] Stopping TCP Broadcaster...")
    STOP = True
signal.signal(signal.SIGINT, handle_exit)
signal.signal(signal.SIGTERM, handle_exit)

# =========================
# Network detection (CIDR from default interface)
# =========================
def run(cmd, check=True, capture=False, shell=False):
    if capture:
        return subprocess.run(cmd, check=check, text=True, capture_output=True, shell=shell)
    return subprocess.run(cmd, check=check, shell=shell)

def get_default_iface_and_cidr():
    """
    Returns CIDR for the default route interface, e.g. '10.15.108.130/17'
    """
    r = run(["ip", "-o", "route", "show", "default"], check=True, capture=True)
    m = re.search(r"\bdev\s+(\S+)", r.stdout)
    if not m:
        raise RuntimeError("Could not determine default interface from `ip route`")
    iface = m.group(1)

    a = run(["ip", "-o", "-f", "inet", "addr", "show", iface], check=True, capture=True)
    m2 = re.search(r"inet\s+(\d+\.\d+\.\d+\.\d+)/(\d+)", a.stdout)
    if not m2:
        raise RuntimeError(f"No IPv4 address found on interface {iface}")
    ip = m2.group(1)
    prefix = m2.group(2)
    return iface, f"{ip}/{prefix}"

# =========================
# Host discovery: port 22 open + SSH banner verification
# =========================
def nmap_candidates_ssh_open(cidr):
    """
    Finds candidates with 22/tcp open using nmap grepable output.
    """
    print(f"[+] Nmap scan for port 22 open across {cidr}...")
    cmd = [
        "sudo", "nmap", "-n", "-Pn",
        "--open", "-p", "22",
        "--max-retries", NMAP_MAX_RETRIES,
        "--host-timeout", NMAP_HOST_TIMEOUT,
        "-oG", "-", cidr
    ]
    r = subprocess.run(cmd, capture_output=True, text=True)
    ips = []
    for line in r.stdout.splitlines():
        if line.startswith("Host:") and "Ports:" in line and "22/open" in line:
            parts = line.split()
            if len(parts) >= 2:
                ips.append(parts[1])

    ips = sorted(set(ips), key=lambda s: tuple(map(int, s.split("."))))
    print(f"[+] Nmap candidates with 22/open: {len(ips)}")
    return ips

def is_real_ssh(ip):
    """
    Verifies port 22 actually speaks SSH by grabbing banner: 'SSH-...'
    """
    try:
        p = subprocess.run(
            ["timeout", str(NC_TIMEOUT_SEC), "bash", "-lc", f"echo | nc -w1 {ip} 22"],
            capture_output=True, text=True
        )
        first = (p.stdout or "").splitlines()[:1]
        return bool(first) and first[0].startswith("SSH-")
    except Exception:
        return False

def discover_hosts_by_ssh_banner(cidr):
    """
    1) nmap -> candidates with 22 open
    2) verify each candidate returns SSH banner
    3) write to hosts.txt
    """
    candidates = nmap_candidates_ssh_open(cidr)
    if not candidates:
        with open(DETECTED_HOSTS_FILE, "w") as f:
            pass
        return []

    print("[+] Verifying candidates by SSH banner (SSH-...) ...")
    live = []
    for i, ip in enumerate(candidates, 1):
        if STOP:
            break
        if is_real_ssh(ip):
            live.append(ip)
        if i % 50 == 0:
            print(f"    checked {i}/{len(candidates)} ... live so far: {len(live)}")

    live = sorted(set(live), key=lambda s: tuple(map(int, s.split("."))))
    with open(DETECTED_HOSTS_FILE, "w") as f:
        for ip in live:
            f.write(ip + "\n")

    print(f"[+] Verified live SSH hosts: {len(live)}")
    print(f"[+] Wrote: {DETECTED_HOSTS_FILE}")
    return live

# =========================
# TCP Packet Broadcast via Scapy (fake session)
# =========================
def send_tcp_message(host, message):
    """
    Crafts a fake TCP handshake sequence to send a message to the target host.
    Even though no listener is running, this generates traffic that students
    can follow in Wireshark.
    """
    sport = random.randint(1024, 65535)
    seq_base = random.randint(1000, 5000)

    syn_pkt = IP(dst=host) / TCP(sport=sport, dport=TCP_PORT, flags="S", seq=seq_base)
    send(syn_pkt, verbose=0)

    psh_pkt = IP(dst=host) / TCP(sport=sport, dport=TCP_PORT, flags="PA", seq=seq_base + 1, ack=1) / Raw(load=message)
    send(psh_pkt, verbose=0)

    fin_pkt = IP(dst=host) / TCP(sport=sport, dport=TCP_PORT, flags="FA", seq=seq_base + 1 + len(message), ack=1)
    send(fin_pkt, verbose=0)

    print(f"[+] Sent fake TCP session to {host}:{TCP_PORT}")

# =========================
# MAIN LOOP
# =========================
def main():
    # Ensure tools are present (netcat is needed for banner checks)
    install_tools()

    try:
        _, cidr = get_default_iface_and_cidr()
    except Exception as e:
        print(f"[!] Could not determine CIDR from default interface: {e}")
        sys.exit(1)

    print(f"[+] Using CIDR from default interface: {cidr}")

    live_hosts = discover_hosts_by_ssh_banner(cidr)
    if not live_hosts:
        print("[-] No live hosts found (verified by SSH banner). Will keep rescanning.")

    total_bursts = max(1, NETWORK_RESCAN_INTERVAL // BROADCAST_INTERVAL)

    while not STOP:
        for burst_num in range(total_bursts):
            if STOP:
                break

            if live_hosts:
                for host in live_hosts:
                    if STOP:
                        break
                    send_tcp_message(host, MESSAGE)

                print(f"[+] Completed burst {burst_num + 1}/{total_bursts}. "
                      f"Sleeping for {BROADCAST_INTERVAL} seconds...")
            time.sleep(BROADCAST_INTERVAL)

        if STOP:
            break

        print("[+] Rescanning network for live hosts (SSH banner verification)...")
        live_hosts = discover_hosts_by_ssh_banner(cidr)

    print("[+] Exiting cleanly.")

if __name__ == "__main__":
    main()