#!/usr/bin/env python3
import subprocess
import time
import signal
import sys
import re
from scapy.all import send, IP, ICMP, Raw

# === AUTO-INSTALL SCAPY IF MISSING ===
try:
    from scapy.all import send, IP, ICMP, Raw
except ImportError:
    print("[!] Scapy not found. Installing it now...")
    subprocess.run(["sudo", "apt", "update", "-y"], capture_output=True, text=True)
    subprocess.run(["sudo", "apt", "install", "-y", "python3-scapy"], capture_output=True, text=True)
    from scapy.all import send, IP, ICMP, Raw  # Retry import after installation

# === CONFIGURATION: Customize Your Flag and Timing Here ===
BOX_VALUE = "1"                # Change the box difficulty
CHALLENGE_VALUE = "2"          # Change the challenge level
INSERT_FLAG_CODE = "Vict1mIP-br0thers"   # Change this to update the challenge flag

NETWORK_RESCAN_INTERVAL = 600  # Rescan every 10 minutes (600 seconds)
BROADCAST_INTERVAL = 10        # Time between each burst wave (seconds)
DETECTED_HOSTS_FILE = "hosts.txt"  # File to store detected live hosts
BURST_COUNT = 5  # Number of ICMP packets per host per burst
PACKET_SIZE = 64  # Number of bytes in the ICMP payload
TOTAL_BURSTS = NETWORK_RESCAN_INTERVAL // BROADCAST_INTERVAL  # Total bursts before rescanning

# Banner verification tuning
NMAP_HOST_TIMEOUT = "800ms"
NMAP_MAX_RETRIES = "0"
NC_TIMEOUT_SEC = 1

# Generate the flag format
FLAG = f"pps{{{BOX_VALUE}x{CHALLENGE_VALUE}_geist_{INSERT_FLAG_CODE}}}"

# Graceful shutdown on Ctrl+C
STOP = False
def handle_exit(sig, frame):
    global STOP
    print("\n[!] Stopping ICMP Broadcaster...")
    STOP = True

signal.signal(signal.SIGINT, handle_exit)
signal.signal(signal.SIGTERM, handle_exit)

# === NEW: ensure netcat + nmap exist for banner-based discovery ===
def ensure_discovery_tools():
    # Install nmap + netcat-openbsd if missing
    def has(bin_name: str) -> bool:
        return subprocess.run(["bash", "-lc", f"command -v {bin_name} >/dev/null 2>&1"]).returncode == 0

    missing = []
    if not has("nmap"):
        missing.append("nmap")
    if not has("nc"):
        missing.append("netcat-openbsd")
    if not has("timeout"):
        missing.append("coreutils")

    if missing:
        print(f"[+] Installing missing discovery tools: {' '.join(missing)}")
        env = dict(**os.environ)
        env["DEBIAN_FRONTEND"] = "noninteractive"
        subprocess.run(["sudo", "apt-get", "update"], env=env, check=False)
        subprocess.run(["sudo", "apt-get", "install", "-y", *missing], env=env, check=False)

# Function to find the lowest IP from ARP table
def get_lowest_arp_ip():
    print("[+] Checking ARP table for active hosts...")

    try:
        arp_output = subprocess.run(["arp", "-a"], capture_output=True, text=True)
        ip_matches = re.findall(r'\((\d+\.\d+\.\d+\.\d+)\)', arp_output.stdout)

        if ip_matches:
            lowest_ip = sorted(ip_matches, key=lambda ip: list(map(int, ip.split('.'))))[0]
            print(f"[+] Lowest IP from ARP: {lowest_ip}")
            return lowest_ip
        else:
            print("[-] No active hosts detected in ARP table.")
            return None

    except Exception as e:
        print(f"[!] Error checking ARP table: {e}")
        return None

# Function to get subnet mask from `ip addr show`
def get_subnet_mask(interface):
    try:
        ip_output = subprocess.run(
            ["ip", "-o", "-f", "inet", "addr", "show", interface],
            capture_output=True, text=True
        )
        match = re.search(r'inet (\d+\.\d+\.\d+\.\d+)/(\d+)', ip_output.stdout)
        if match:
            subnet_mask = match.group(2)
            print(f"[+] Detected subnet mask: /{subnet_mask}")
            return subnet_mask
    except Exception as e:
        print(f"[!] Failed to detect subnet mask: {e}")

    return None

# Function to detect the real network subnet using ARP + IP
def detect_real_subnet():
    print("[+] Detecting the actual subnet...")

    base_ip = get_lowest_arp_ip()
    if not base_ip:
        print("[!] Could not determine base IP. Exiting.")
        sys.exit(1)

    try:
        ip_route_output = subprocess.run(["ip", "-o", "route", "show", "default"], capture_output=True, text=True)
        match = re.search(r'default via (\d+\.\d+\.\d+\.\d+) dev (\S+)', ip_route_output.stdout)
        if match:
            interface = match.group(2)
            subnet_mask = get_subnet_mask(interface)
            if subnet_mask:
                subnet = f"{base_ip}/{subnet_mask}"
                print(f"[+] Using network subnet: {subnet}")
                return subnet
    except Exception as e:
        print(f"[!] Failed to detect network: {e}")

    return None

# === NEW HOST DISCOVERY: nmap candidates on 22 + SSH banner verification ===
def nmap_candidates_ssh_open(subnet):
    print(f"[+] Nmap scan for 22/open in {subnet} (candidates)...")
    cmd = [
        "sudo", "nmap", "-n", "-Pn",
        "--open", "-p", "22",
        "--max-retries", NMAP_MAX_RETRIES,
        "--host-timeout", NMAP_HOST_TIMEOUT,
        "-oG", "-", subnet
    ]
    r = subprocess.run(cmd, capture_output=True, text=True)
    ips = []
    for line in r.stdout.splitlines():
        if line.startswith("Host:") and "Ports:" in line and "22/open" in line:
            parts = line.split()
            if len(parts) >= 2:
                ips.append(parts[1])
    ips = sorted(set(ips), key=lambda s: tuple(map(int, s.split("."))))
    print(f"[+] Candidates with 22/open: {len(ips)}")
    return ips

def is_real_ssh(ip):
    try:
        p = subprocess.run(
            ["timeout", str(NC_TIMEOUT_SEC), "bash", "-lc", f"echo | nc -w1 {ip} 22"],
            capture_output=True, text=True
        )
        first = (p.stdout or "").splitlines()[:1]
        return bool(first) and first[0].startswith("SSH-")
    except Exception:
        return False

def discover_hosts(subnet):
    """
    Replaces the old -sn discovery:
      1) nmap finds 22/open candidates
      2) verify candidates return SSH banner
      3) write verified hosts to DETECTED_HOSTS_FILE
    """
    print(f"[+] Discovering live hosts in {subnet} via SSH banner on port 22...")
    candidates = nmap_candidates_ssh_open(subnet)
    live = []

    if candidates:
        print("[+] Verifying candidates by SSH banner (SSH-...) ...")
        for i, ip in enumerate(candidates, 1):
            if STOP:
                break
            if is_real_ssh(ip):
                live.append(ip)
            if i % 50 == 0:
                print(f"    checked {i}/{len(candidates)} ... live so far: {len(live)}")

    live = sorted(set(live), key=lambda s: tuple(map(int, s.split("."))))

    with open(DETECTED_HOSTS_FILE, "w") as f:
        for ip in live:
            f.write(ip + "\n")

    if not live:
        print("[-] No verified live hosts found (SSH banner).")
    else:
        print(f"[+] Verified live hosts: {len(live)}")
        print(f"[+] Wrote: {DETECTED_HOSTS_FILE}")

    return live

# Function to send ICMP bursts to live hosts
def send_icmp_broadcast(live_hosts, burst_num):
    if not live_hosts:
        print("[-] No hosts available to send ICMP messages.")
        return

    print(f"[+] Sending wave {burst_num + 1}/{TOTAL_BURSTS}: {BURST_COUNT} ICMP packets to {len(live_hosts)} hosts...")

    payload = FLAG.ljust(PACKET_SIZE, "X")
    for host in live_hosts:
        for _ in range(BURST_COUNT):
            if STOP:
                return
            send(IP(dst=host)/ICMP()/Raw(load=payload), verbose=0)

# Main loop
def main():
    # NOTE: Keep everything the same, but ensure banner-discovery tools exist
    # (If you don't want installs here, remove this call and install via deploy script.)
    try:
        import os  # local import to avoid changing your header imports
        ensure_discovery_tools()
    except Exception:
        pass

    detected_subnet = detect_real_subnet()
    if not detected_subnet:
        print("[!] Could not determine network. Exiting.")
        sys.exit(1)

    live_hosts = discover_hosts(detected_subnet)  # Initial scan

    while not STOP:
        for burst_num in range(TOTAL_BURSTS):  # Send ICMP bursts in waves
            if STOP:
                break
            send_icmp_broadcast(live_hosts, burst_num)
            print(f"[+] Sleeping for {BROADCAST_INTERVAL} seconds before next wave...")
            time.sleep(BROADCAST_INTERVAL)

        if STOP:
            break
        print(f"[+] Rescanning network after {NETWORK_RESCAN_INTERVAL} seconds...")
        live_hosts = discover_hosts(detected_subnet)

    print("[+] Exiting cleanly.")

if __name__ == "__main__":
    main()