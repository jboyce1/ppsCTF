#!/usr/bin/env python3
import os
import subprocess
import time
import signal
import sys
import re
import random
from typing import List, Tuple

# ============================================================
# CONFIGURATION
# ============================================================
BOX_VALUE = "1"                      # Change box difficulty
CHALLENGE_VALUE = "2"                # Change challenge level
INSERT_FLAG_CODE = "tcpv1cP@ass-sister"  # Change challenge flag
TCP_PORT = 5555                      # Port you want the fake TCP traffic to target

# Rescan every 5 minutes so late logins get it quickly
NETWORK_RESCAN_INTERVAL = 300        # 5 minutes
BROADCAST_INTERVAL = 10              # seconds between bursts
DETECTED_HOSTS_FILE = "hosts.txt"    # verified live hosts written here

# Banner verification settings
NMAP_HOST_TIMEOUT = "800ms"
NMAP_MAX_RETRIES = "0"
NC_TIMEOUT_SEC = 1

# ============================================================
# MESSAGE (payload students will see in Wireshark)
# ============================================================
MESSAGE = (
    f"pps{{{BOX_VALUE}x{CHALLENGE_VALUE}_geist_{INSERT_FLAG_CODE}}} "
    "I would really appreciate some help from anyone who can see this, our family is being bullied..."
    "a group of sisters, who all have the same stupid first letter of their name"
    " has been harrassing our computer. My brother stopped using the computer so "
    " I am giving his username and password in case you can help u:victoria2 p:V1ct0ry!"
    " Thanks for any help -vera"
)

# ============================================================
# TOOLING INSTALL/VERIFY
# ============================================================
def _apt_install(pkgs: List[str]) -> None:
    env = os.environ.copy()
    env["DEBIAN_FRONTEND"] = "noninteractive"
    subprocess.run(["sudo", "apt-get", "update"], env=env, check=True)
    subprocess.run(["sudo", "apt-get", "install", "-y"] + pkgs, env=env, check=True)

def ensure_tools() -> None:
    """
    Ensures required tools exist. Installs missing items using apt-get.
    We keep this lightweight and only install what's actually missing.
    """
    needed = []

    # core utils
    for bin_name, pkg in [
        ("nmap", "nmap"),
        ("nc", "netcat-openbsd"),   # IMPORTANT: banner verification
        ("timeout", "coreutils"),
    ]:
        if subprocess.run(["bash", "-lc", f"command -v {bin_name} >/dev/null 2>&1"]).returncode != 0:
            needed.append(pkg)

    # optional-but-useful tools user mentioned
    for bin_name, pkg in [
        ("tcpdump", "tcpdump"),
        ("iftop", "iftop"),
    ]:
        if subprocess.run(["bash", "-lc", f"command -v {bin_name} >/dev/null 2>&1"]).returncode != 0:
            needed.append(pkg)

    # scapy (python3-scapy package)
    try:
        import scapy  # noqa: F401
    except Exception:
        needed.append("python3-scapy")

    # de-dupe
    needed = sorted(set(needed))
    if needed:
        print(f"[+] Installing missing tools: {' '.join(needed)}")
        _apt_install(needed)
        print("[+] Tool installation complete.")

def check_and_import_scapy():
    """
    Attempts to import Scapy. If it fails, installs required packages and restarts script.
    """
    try:
        from scapy.all import send, IP, TCP, Raw  # type: ignore
        return send, IP, TCP, Raw
    except ImportError:
        print("[!] Scapy import failed. Installing tools and restarting...")
        ensure_tools()
        os.execv(sys.executable, [sys.executable] + sys.argv)

# ============================================================
# Graceful shutdown
# ============================================================
STOP = False
def handle_exit(sig, frame):
    global STOP
    print("\n[!] Stopping TCP Broadcaster...")
    STOP = True

signal.signal(signal.SIGINT, handle_exit)
signal.signal(signal.SIGTERM, handle_exit)

# Ensure tools exist before importing scapy
ensure_tools()
send, IP, TCP, Raw = check_and_import_scapy()

# ============================================================
# Network helpers
# ============================================================
def run(cmd: List[str], check: bool = False) -> subprocess.CompletedProcess:
    return subprocess.run(cmd, capture_output=True, text=True, check=check)

def get_default_iface_and_cidr() -> Tuple[str, str]:
    """
    Returns (iface, cidr) from the system's default route interface.
    Example: ('eth0', '10.15.108.130/17')
    """
    r = run(["ip", "-o", "route", "show", "default"], check=True)
    m = re.search(r"\bdev\s+(\S+)", r.stdout)
    if not m:
        raise RuntimeError("Could not determine default interface from `ip route`")
    iface = m.group(1)

    a = run(["ip", "-o", "-f", "inet", "addr", "show", iface], check=True)
    m2 = re.search(r"inet\s+(\d+\.\d+\.\d+\.\d+)/(\d+)", a.stdout)
    if not m2:
        raise RuntimeError(f"No IPv4 address found on interface {iface}")
    ip = m2.group(1)
    prefix = m2.group(2)

    return iface, f"{ip}/{prefix}"

# ============================================================
# Live host discovery: port 22 open + SSH banner verification
# ============================================================
def nmap_candidates_ssh_open(cidr: str) -> List[str]:
    """
    Uses nmap to find IPs with TCP/22 open.
    In cloud ranges this can still over-report, so we verify with SSH banner next.
    """
    print(f"[+] Nmap scan for port 22 open across {cidr}...")
    cmd = [
        "sudo", "nmap", "-n", "-Pn",
        "--open", "-p", "22",
        "--max-retries", NMAP_MAX_RETRIES,
        "--host-timeout", NMAP_HOST_TIMEOUT,
        "-oG", "-", cidr
    ]
    r = subprocess.run(cmd, capture_output=True, text=True)
    ips = []
    for line in r.stdout.splitlines():
        # Grepable format contains: Host: <ip> ... Ports: 22/open/tcp//ssh///
        if line.startswith("Host:") and "Ports:" in line and "22/open" in line:
            parts = line.split()
            if len(parts) >= 2:
                ips.append(parts[1])

    # unique + numeric sort
    ips = sorted(set(ips), key=lambda s: tuple(map(int, s.split("."))))
    print(f"[+] Nmap candidates with 22/open: {len(ips)}")
    return ips

def is_real_ssh(ip: str) -> bool:
    """
    Verifies that port 22 actually speaks SSH by reading the banner line.
    Uses netcat (nc). True only if we see 'SSH-' at start of banner.
    """
    try:
        # echo | nc -w1 <ip> 22 -> should return SSH-2.0-OpenSSH_...
        p = subprocess.run(
            ["timeout", str(NC_TIMEOUT_SEC), "bash", "-lc", f"echo | nc -w1 {ip} 22"],
            capture_output=True, text=True
        )
        first = (p.stdout or "").splitlines()[:1]
        if not first:
            return False
        return first[0].startswith("SSH-")
    except Exception:
        return False

def discover_live_hosts_by_ssh_banner(cidr: str) -> List[str]:
    """
    Full discovery:
      1) nmap finds 22/open candidates
      2) verify each candidate returns SSH banner
      3) write to DETECTED_HOSTS_FILE
    """
    candidates = nmap_candidates_ssh_open(cidr)
    if not candidates:
        with open(DETECTED_HOSTS_FILE, "w") as f:
            pass
        return []

    print("[+] Verifying candidates by SSH banner (SSH-...) ...")
    live: List[str] = []

    # Sequential verification is simplest/reliable.
    # If you ever want this faster, we can add a thread pool later.
    for idx, ip in enumerate(candidates, 1):
        if STOP:
            break
        if is_real_ssh(ip):
            live.append(ip)

        if idx % 50 == 0:
            print(f"    checked {idx}/{len(candidates)} ... live so far: {len(live)}")

    live = sorted(set(live), key=lambda s: tuple(map(int, s.split("."))))

    with open(DETECTED_HOSTS_FILE, "w") as f:
        for ip in live:
            f.write(ip + "\n")

    print(f"[+] Verified live SSH hosts: {len(live)}")
    print(f"[+] Wrote: {DETECTED_HOSTS_FILE}")
    return live

# ============================================================
# TCP Packet Broadcast via Scapy (fake session)
# ============================================================
def send_tcp_message(host: str, message: str) -> None:
    """
    Crafts a fake TCP "session" to generate traffic students can follow in Wireshark.
    """
    sport = random.randint(1024, 65535)
    seq_base = random.randint(1000, 5000)

    syn_pkt = IP(dst=host) / TCP(sport=sport, dport=TCP_PORT, flags="S", seq=seq_base)
    send(syn_pkt, verbose=0)

    psh_pkt = (
        IP(dst=host)
        / TCP(sport=sport, dport=TCP_PORT, flags="PA", seq=seq_base + 1, ack=1)
        / Raw(load=message)
    )
    send(psh_pkt, verbose=0)

    fin_pkt = IP(dst=host) / TCP(
        sport=sport,
        dport=TCP_PORT,
        flags="FA",
        seq=seq_base + 1 + len(message),
        ack=1
    )
    send(fin_pkt, verbose=0)

# ============================================================
# Main Loop
# ============================================================
def main():
    try:
        iface, cidr = get_default_iface_and_cidr()
    except Exception as e:
        print(f"[!] Could not determine default interface/CIDR: {e}")
        sys.exit(1)

    print(f"[+] Default interface: {iface}")
    print(f"[+] Using CIDR:         {cidr}")
    print(f"[+] Rescan interval:    {NETWORK_RESCAN_INTERVAL}s (5 minutes)")
    print(f"[+] Burst interval:     {BROADCAST_INTERVAL}s")
    print(f"[+] TCP port:           {TCP_PORT}")
    print(f"[+] Message prefix:     {MESSAGE[:80]}...")

    total_bursts = max(1, NETWORK_RESCAN_INTERVAL // BROADCAST_INTERVAL)

    live_hosts = discover_live_hosts_by_ssh_banner(cidr)
    if not live_hosts:
        print("[-] No verified live SSH hosts found. Will keep rescanning...")
    else:
        print(f"[+] Starting broadcasts to {len(live_hosts)} verified hosts.")

    while not STOP:
        for burst_num in range(total_bursts):
            if STOP:
                break

            # If nobody was found, don't spam; just wait until next rescan.
            if live_hosts:
                print(f"[+] Burst {burst_num + 1}/{total_bursts} -> {len(live_hosts)} hosts")
                for host in live_hosts:
                    if STOP:
                        break
                    send_tcp_message(host, MESSAGE)

            time.sleep(BROADCAST_INTERVAL)

        if STOP:
            break

        print("[+] Rescanning network (SSH banner verification)...")
        live_hosts = discover_live_hosts_by_ssh_banner(cidr)

    print("[+] Exiting cleanly.")

if __name__ == "__main__":
    main()