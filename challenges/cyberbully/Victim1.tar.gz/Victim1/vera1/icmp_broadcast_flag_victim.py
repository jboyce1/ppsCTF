#!/usr/bin/env python3
import subprocess
import time
import signal
import sys
import re
from typing import List, Optional

# === AUTO-INSTALL SCAPY IF MISSING ===
try:
    from scapy.all import send, IP, ICMP, Raw  # type: ignore
except ImportError:
    print("[!] Scapy not found. Installing it now...")
    subprocess.run(["sudo", "apt", "update", "-y"], capture_output=True, text=True)
    subprocess.run(["sudo", "apt", "install", "python3-scapy", "-y"], capture_output=True, text=True)
    from scapy.all import send, IP, ICMP, Raw  # type: ignore

# === CONFIGURATION: Customize Your Flag and Timing Here ===
BOX_VALUE = "1"
CHALLENGE_VALUE = "2"
INSERT_FLAG_CODE = "Vict1mIP-sisters"

NETWORK_RESCAN_INTERVAL = 300  # seconds
BROADCAST_INTERVAL = 150        # seconds between waves
DETECTED_HOSTS_FILE = "hosts.txt"

BURST_COUNT = 5
PACKET_SIZE = 64
TOTAL_BURSTS = max(1, NETWORK_RESCAN_INTERVAL // BROADCAST_INTERVAL)

# Scan tuning (AWS range friendly)
NMAP_HOST_TIMEOUT = "800ms"
NMAP_MAX_RETRIES = "0"
NC_TIMEOUT_SEC = 1
NC_PARALLEL = 80  # only used by shell xargs if you keep that approach; here we do python loops

# Generate the flag format
FLAG = f"pps{{{BOX_VALUE}x{CHALLENGE_VALUE}_geist_{INSERT_FLAG_CODE}}}"

# Graceful shutdown on Ctrl+C
STOP = False
def handle_exit(sig, frame):
    global STOP
    print("\n[!] Stopping ICMP Broadcaster...")
    STOP = True
signal.signal(signal.SIGINT, handle_exit)
signal.signal(signal.SIGTERM, handle_exit)

def run(cmd: List[str], check: bool = False) -> subprocess.CompletedProcess:
    return subprocess.run(cmd, capture_output=True, text=True, check=check)

def get_default_iface_and_cidr() -> str:
    """
    Returns CIDR for the default route interface, like '10.15.108.130/17'
    """
    r = run(["ip", "-o", "route", "show", "default"], check=True)
    m = re.search(r"\bdev\s+(\S+)", r.stdout)
    if not m:
        raise RuntimeError("Could not determine default interface from `ip route`")
    iface = m.group(1)

    a = run(["ip", "-o", "-f", "inet", "addr", "show", iface], check=True)
    m2 = re.search(r"inet\s+(\d+\.\d+\.\d+\.\d+)/(\d+)", a.stdout)
    if not m2:
        raise RuntimeError(f"No IPv4 address found on interface {iface}")
    ip = m2.group(1)
    prefix = m2.group(2)
    return f"{ip}/{prefix}"

def nmap_candidates_ssh_open(cidr: str) -> List[str]:
    """
    Uses nmap to find IPs with TCP/22 open. This can still over-report on cloud fabrics,
    so we verify with an SSH banner next.
    """
    print(f"[+] Nmap scan for port 22 open across {cidr}...")
    cmd = [
        "sudo", "nmap", "-n", "-Pn",
        "--open", "-p", "22",
        "--max-retries", NMAP_MAX_RETRIES,
        "--host-timeout", NMAP_HOST_TIMEOUT,
        "-oG", "-", cidr
    ]
    r = subprocess.run(cmd, capture_output=True, text=True)
    ips = []
    for line in r.stdout.splitlines():
        # Grepable line format contains: Host: <ip> ... Ports: 22/open/tcp//ssh///
        if "Ports:" in line and "22/open" in line and line.startswith("Host:"):
            parts = line.split()
            # Host: <ip>
            if len(parts) >= 2:
                ips.append(parts[1])
    ips = sorted(set(ips), key=lambda s: tuple(map(int, s.split("."))))
    print(f"[+] Nmap candidates with 22/open: {len(ips)}")
    return ips

def is_real_ssh(ip: str) -> bool:
    """
    Verifies that port 22 speaks SSH by reading the banner line.
    Requires `nc` installed (netcat-openbsd is standard on Kali/Ubuntu).
    """
    try:
        # echo | nc -w1 <ip> 22  -> should return SSH-2.0-...
        p = subprocess.run(
            ["timeout", str(NC_TIMEOUT_SEC), "bash", "-c", f"echo | nc -w1 {ip} 22"],
            capture_output=True, text=True
        )
        banner = (p.stdout or "").splitlines()[:1]
        if not banner:
            return False
        return banner[0].startswith("SSH-")
    except Exception:
        return False

def discover_real_hosts(cidr: str) -> List[str]:
    """
    Full discovery:
    1) nmap finds 22/open candidates
    2) verify each candidate returns SSH banner
    3) write to hosts file
    """
    candidates = nmap_candidates_ssh_open(cidr)
    if not candidates:
        return []

    print("[+] Verifying candidates by SSH banner (SSH-...) ...")
    live = []
    # Sequential is simplest and reliable. If you want parallel, we can add it after.
    for i, ip in enumerate(candidates, 1):
        if STOP:
            break
        if is_real_ssh(ip):
            live.append(ip)

        # lightweight progress every 50
        if i % 50 == 0:
            print(f"    checked {i}/{len(candidates)} ... live so far: {len(live)}")

    live = sorted(set(live), key=lambda s: tuple(map(int, s.split("."))))
    with open(DETECTED_HOSTS_FILE, "w") as f:
        for ip in live:
            f.write(ip + "\n")

    print(f"[+] Verified live SSH hosts: {len(live)}")
    print(f"[+] Wrote: {DETECTED_HOSTS_FILE}")
    return live

def send_icmp_broadcast(live_hosts: List[str], wave_num: int):
    if not live_hosts:
        print("[-] No hosts available to send ICMP messages.")
        return

    print(f"[+] Sending wave {wave_num + 1}/{TOTAL_BURSTS}: "
          f"{BURST_COUNT} ICMP packets to {len(live_hosts)} hosts...")

    payload = FLAG.ljust(PACKET_SIZE, "X")
    for host in live_hosts:
        for _ in range(BURST_COUNT):
            if STOP:
                return
            send(IP(dst=host)/ICMP()/Raw(load=payload), verbose=0)

def main():
    try:
        cidr = get_default_iface_and_cidr()
    except Exception as e:
        print(f"[!] Could not determine CIDR from default interface: {e}")
        sys.exit(1)

    print(f"[+] Using CIDR from default interface: {cidr}")
    live_hosts = discover_real_hosts(cidr)

    while not STOP:
        for wave in range(TOTAL_BURSTS):
            if STOP:
                break
            send_icmp_broadcast(live_hosts, wave)
            if STOP:
                break
            time.sleep(BROADCAST_INTERVAL)

        if STOP:
            break

        print(f"[+] Rescanning network after {NETWORK_RESCAN_INTERVAL} seconds...")
        live_hosts = discover_real_hosts(cidr)

    print("[+] Exiting cleanly.")

if __name__ == "__main__":
    main()
