#!/bin/bash

# Get the directory where the script is located
script_dir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

# Define the file name
filename="$script_dir/yup.txt"

# Create and write "Wrong Answer!" to the text file
echo "pps{FUNnewGAM3_C0rrect}" > "$filename"

# Open the text file with Gedit
gedit "$filename"
