#!/bin/bash

# Get the directory where the script is located
script_dir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

# Define the file name
filename="$script_dir/nope.txt"

# Create and write "pps{FUNnewGAME_C0rrect}" to the text file
echo "nope!" > "$filename"

# Open the text file with Gedit
gedit "$filename"
