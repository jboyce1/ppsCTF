#!/bin/bash

# Get the directory where the script is located
script_dir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

# Define the file name
filename="$script_dir/WrongAnswer.txt"

# Create and write "Wrong Answer!" to the text file
echo "Wrong !!!" > "$filename"

# Open the text file with Gedit
gedit "$filename"
