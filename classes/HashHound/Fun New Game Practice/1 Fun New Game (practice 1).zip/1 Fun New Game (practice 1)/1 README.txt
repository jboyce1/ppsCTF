Check out this game!
You will have to use sudo md5sum <filename>
md5sum: d00ab92efe40c70d1f70f54257653e70






Walkthrough:
ctrl + alt + t
cd /Desktop/
ls
cd Unit 1: Reverse Engineering
ls
cd Checking Hash Functions/
ls
cd 1 Fun New Game
md5sum FuNeWgAmE.sh
************************************ FuNeWgAmE.sh
md5sum funnewGAME.sh
************************************ funnewGAME.sh
etc etc
double click on game with match of:
cf9406bee74516677ca364c682c96d90

