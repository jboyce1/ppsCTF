Check out this game!
You will have to use sudo md5sum <filename>
md5sum: eac07a8220e58d3bd93160dd1436bb32






Walkthrough:
ctrl + alt + t
cd /Desktop/
ls
cd Unit 1: Reverse Engineering
ls
cd Checking Hash Functions/
ls
cd 1 Fun New Game
md5sum FuNeWgAmE.sh
************************************ FuNeWgAmE.sh
md5sum funnewGAME.sh
************************************ funnewGAME.sh
etc etc
double click on game with match of:
cf9406bee74516677ca364c682c96d90

