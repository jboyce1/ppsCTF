#!/bin/bash

# Get the directory where the script is located
script_dir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

# Define the file name
filename="$script_dir/1CorrectAnswer.txt"

# Create and write "pps{FUNnewGAME_C0rrect}" to the text file
echo "Wrong!!!" > "$filename"

# Open the text file with Gedit
gedit "$filename"
