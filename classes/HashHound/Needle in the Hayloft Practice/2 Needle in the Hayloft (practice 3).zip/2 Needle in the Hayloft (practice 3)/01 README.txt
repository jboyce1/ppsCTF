
Here is your md5 needle: 8244843bc47ad3ca9c04ca721af6b93c

step1:
Navigate to the '2 Needle in the Hayloft' directory 

step2:
Make a text file using the following command:
find . -type f -exec md5sum {} \; > 01md5sums.txt

Explaination for command
    find . searches for files and directories starting from the current directory (.).
    -type f specifies that we are interested in files only, not directories.
    -exec md5sum {} \; executes the md5sum command on each file found by find. {} represents the current file being processed by find.
    > md5sums.txt redirects the output (MD5 checksums) to a file named md5sums.txt.
    
step3:
open the text file and search (ctrl+f) the needle you are looking for

step4:open the file and find the flag

For more informaiton on the functions: 
man find
man 
