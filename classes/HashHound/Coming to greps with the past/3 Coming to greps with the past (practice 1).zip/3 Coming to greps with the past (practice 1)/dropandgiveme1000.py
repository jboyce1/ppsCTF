import hashlib
import os

# Function to calculate the MD5 hash of a string
def calculate_md5_hash(text):
    hasher = hashlib.md5()
    hasher.update(text.encode('utf-8'))
    return hasher.hexdigest()

# Create 100 text files with different content
for i in range(1, 1001):
    file_name = f"youll_need_a_magnet_for_this_needle{i}.txt"
    file_content = f"not the needle {i}\n"

    # Calculate MD5 hash of the content
    md5_hash = calculate_md5_hash(file_content)

    # Write the content to the file
    with open(file_name, 'w') as file:
        file.write(file_content)

    print(f"Created file: {file_name}, MD5 hash: {md5_hash}")

print("Script completed.")
