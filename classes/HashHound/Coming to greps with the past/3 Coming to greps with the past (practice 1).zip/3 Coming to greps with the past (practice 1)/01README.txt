You need to find the suspicious needle. They were all good when they left but something changed. The 
knowngood_md5sums_filenames.txt is a list of all the unsuspicious files.


#Step 1
#Extract all of the hashes from the knowngood_md5sums_filenames.txt
cut -d ' ' -f 1 knowngood_md5sums_filenames.txt> knowngood_hashes.txt

#Step2
#Find all the md5sums in the directory
find . -type f -exec md5sum {} \; > current_md5sums_filenames.txt

#Step3
#Extract all hashes from the current_md5sums_filenames.txt
cut -d ' ' -f 1 current_md5sums_filenames.txt > current_hashes.txt


#Step4
#Search for lines in 'current_hashes.txt' that are not 'known_goodhashes.txt' and write them to a new file called 'non_matching_hashes.txt'
grep -vf knowngood_hashes.txt current_hashes.txt > non_matching_hashes.txt

#Step5
#Find and inspect all the files in the non_matching_hashes.txt by finding (ctrl+f) the hashes in the current_md5sums_filenames.txt
#OR use grep again to 
grep -F -f non_matching_hashes.txt current_md5sums_filenames.txt

