MsDisin — Unique Counts Key
Sometimes the world is a web of lies. Be a spider.

FILES
- 3  (the source text)
- msdis.zip  (locked payload)

MISSION
Find the EXACT words that occur exactly the following number of times in the text:

    59, 67, 73, 79, 97

RULES
- Case-insensitive
- Words are alphabetic tokens (punctuation ignored)
- Each target count corresponds to exactly ONE word in this book (no ties)
- Your key phrase is the words in ASCENDING COUNT ORDER, separated by spaces

ZIP PASSWORD
The password for msdis.zip is the CamelCase version of your key phrase (no spaces).
Example: "red fox winter" -> "RedFoxWinter"
