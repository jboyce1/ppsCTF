Fun New Game - Practice 2

Target MD5: 6ca532bbbea3943300dda165038aac52

1. Open this extracted folder in the file manager.
2. Right-click an empty space and choose Open Terminal Here.
3. Type ls and press Enter to list the files.
4. Type md5sum FUNNEWGAME.html and press Enter.
5. Compare the 32-character hash with the target above.
6. Repeat with each of the other .html filenames, one at a time.
   Capital letters matter. Use the exact filename shown by ls.
7. Once you have checked all five files, return to the file manager.
8. Double-click ONLY the .html file whose hash matches the target.
   It opens in your web browser and shows your flag.

No sudo is needed. Do not edit or open the game files before checking
their hashes. Record each filename and hash as you go.
